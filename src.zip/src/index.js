import React from 'react';
import ReactDOM from 'react-dom';
import App from './app';
import { BrowserRouter,Router } from 'react-router-dom';
import api from './api'

ReactDOM.render(
  <BrowserRouter>
    <App/>
    </BrowserRouter>

,document.getElementById("root"));








