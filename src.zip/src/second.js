import React from "react";
import  ReactDOM  from "react";
import "./style.css"
import logo from "./logo.png"
import "./second.html"
ReactDOM.render
(
    <div className="main"> <header>
    <img src={logo} alt="" ></img>
    <input type="search" name="" id="" placeholder="Search..."/>
    </header>;
    </div>

,document.getElementById("root1"));
