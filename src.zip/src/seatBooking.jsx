import React from "react";
import "./style.css";
import arr,{height} from "./seatCount";
import tv from "./LA9700_large_04.jpg";
import {useState} from 'react';


function SeatBooking(movie) {
  const [myArray, setMyArray] = useState([]);
  const [isColorChanged, setIsColorChanged] = useState(false);
  const addArray = (chars,seat) => {
    const comb=''+seat;
    const combi=chars+comb;
    setMyArray([...myArray, combi]);
    setIsColorChanged(true);
  };
  return <div>
    <br />
    <br />
    <h2>{movie?.title}</h2>
    <hr />
    <br />
    <table className="table">
      <tr>
        <td width={1000}>
  {height.map((value, ind) => (<div key={ind}>
    <div className="seatss">
    {String.fromCharCode(65+ind)}
    </div>
  {arr.map((value, index) => (
    <div key={index} className="seats" onClick={() => addArray(String.fromCharCode(65+ind),value)} style={{backgroundColor:isColorChanged ? 'green' : 'initial' }}>
      {value}
    </div>
  ))}</div>))}
  <br />
  <img src={tv} alt="" className="screen"/>
  </td>
  <td>  
    Seats: {myArray.length > 0 ? myArray.map(char=>(<div>{char}</div>)) : ''}
    <hr />
    total: {myArray.length>0 ? myArray.length*200:''}
  <button className="book"><b>CONFIRM</b></button>
  </td>
  </tr>
  </table>
  </div>
}


export default SeatBooking;
