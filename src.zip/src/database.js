const { MongoClient } = require("mongodb");
// Replace the uri string with your connection string.
const uri = "mongodb+srv://aadiudu:scared2compile@scared2compile.wxkvott.mongodb.net/?retryWrites=true&w=majority";
const client = new MongoClient(uri);
async function run() {
  try {
    const database = client.db('Scared2Compile');
    const movies = database.collection('scared2compile');
    // Query for a movie that has the title 'Back to the Future'
    const query = { film: 'Leo',
                    seats:[1,2,3] };
    const movie = await movies.insertOne(query);
    const moviee= await movies.findOne(query);
    
    console.log(moviee);
  } finally {
    // Ensures that the client will close when you finish/error
    await client.close();
  }
}
run().catch(console.dir);